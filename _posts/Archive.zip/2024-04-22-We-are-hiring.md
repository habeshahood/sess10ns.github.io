---
layout: post
title: "Join Us at ሐበሻ HOOD!"
author: sal
categories: [Careers, Music, Technology]
image: assets/images/hiring.jpg
---

## We're Hiring Creative Content Creators!

Are you passionate about making an impact in the Habesha music scene? Habesha Hood is on the lookout for talented individuals to join our vibrant team. We are a dynamic platform at the forefront of Habesha hip hop, trap, and drill music.

**We're looking for:**
- **Content Creators:** If you have a passion for music and a knack for creating engaging digital content, we need you!
- **Video Editors and Producers:** Talented in storytelling through video? Come help us craft compelling visual narratives and get paid.
- **Social Media Managers:** Expert in driving engagement and growth on social platforms? Your skills are in demand.

**Requirements:**
- Strong creativity and a deep passion for Habesha talent.
- Proven experience in your field, whether it be content creation, social media management, or video production.
- Excellent communication skills and the ability to thrive in a fast-paced environment.

### Why Join ሐበሻ HOOD?
- Work with a team passionate about promoting Habesha talent globally.
- Enjoy a creative and supportive work environment.
- Grow your career and help expand the reach of Habesha culture.

<div style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
    <a href="https://habeshahood.com/apply/">
        <img src="/assets/images/apply-button.png" alt="Apply Now">
    </a>
    <p>For more details and to apply, click the button above and join our team. Let's make history together!</p>
</div>

![Habesha Hood Team](/assets/images/team-photo.jpg)

Join us and be part of showcasing Habesha talent to the world!
