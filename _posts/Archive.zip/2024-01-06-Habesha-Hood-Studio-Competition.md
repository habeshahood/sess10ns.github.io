---
layout: post
title:  "COMPETITION: Win Studio Equipment Worth USD $2000!"
author: sal
categories: [ Entertainment, Community Event]
image: assets/images/competition.jpg
---

In light of recent events at our studio, we're thrilled to announce the **Habesha Hood Studio Raffle**. This is not just a chance to win big but also an opportunity to support the rebuilding of our studio. Get ready to win amazing prizes and enjoy exclusive offers!

## The Raffle Details

We're offering 400 tickets, each priced at 1000 birr. The proceeds will go towards purchasing new studio equipment after our unfortunate robbery incident.

### Grand Prize

- **$2000 Worth of Studio Equipment**
- **Total Number of Tickets:** 400
- **Price per Ticket:** 1000 birr

- **21.5” iMac Quad Core i5 2.7GHz, 16GB Ram, 1TB SSD or equivalent spec laptop**
- **Software Included:**
  - PRO TOOLS 10HD
  - Waves plug-ins
  - MiXED iN KEY
  - MELODYNE
  - REASON
  - FL Studio
  - VIRTUAL DJ
  - LOGIC PRO X
  - FINAL CUT PRO X
  - ADOBE SUiTE CS6
  - LiGHT ROOM
  - MiCROSOFT OFFICE
- **Accessories:**
  - Wireless keyboard and mouse
  - Scarlet 2i2 Interface
  - Midi Mini Keyboard with Drum Pads
  - Black 5” Yamaha HS5 Pair with Speaker Foam
  - Pair of AKG Headphones
  - AKG Condenser Microphone
  - Black Mic Reflector Shield and Mic Stand
  - Black Studio Table
  - Black Studio Office Chair
- **Includes all necessary cables for setup**


### Special Offer for Participants
- Every participant who purchases a raffle ticket but doesn't win will receive a complimentary session at our new studio when they book a session with us. This means you get two sessions for the price of one!

## How to Enter

Ready to dive into the chance of winning amazing studio equipment? Entering the Habesha Hood Raffle is easy and straightforward:

1. **Purchase Your Raffle Ticket:** Each ticket costs 1000 birr.
2. **Visit the Ticket Purchase Page:** Get your ticket by clicking [here](https://chapa.link/event/view/EV-MZ2qEOtDLIlT).
3. **Complete Your Purchase:** Follow the instructions on the Chapa payment portal. The small processing fee ensures a smooth and secure transaction.
4. **Keep Your Confirmation:** Once your purchase is complete, you’ll receive a confirmation. Keep this safe as you’ll need it for the raffle draw.


## Rebuilding Together

By participating, not only do you get a chance to win and avail an exclusive studio session, but you also contribute to the rebirth of the Habesha Hood Studio. Your support means the world to us, and we can't wait to welcome you to our new and improved studio.

## Terms and Conditions

- The raffle is open to everyone.
- Full terms and conditions can be found at [Habesha Hood Raffle Terms and Conditions](/c-terms/).
---

Stay tuned for more updates and don't miss your chance to be part of this exciting journey!

For more information, contact us on telegram.
