---
layout: post
title:  "Yazew Belw hits Top 50 on YouTube in Addis Abeba!"
categories: [ Hip Hop, Ethiopia ]
author: sal
image: assets/images/1.jpg
---
The MOB collective, comprising Tamula Rasta, AK Blata, and Fla Pablo, is making waves in the Ethiopian hip-hop scene with their distinctive and vibrant style. Since the launch of their groundbreaking music video in collaboration with us, they've experienced an extraordinary rise in popularity. This trio's innovative approach to music has not only captivated audiences across Ethiopia but has also propelled them into the top 50 songs on the YouTube charts in Addis Abeba, marking a significant milestone in their artistic journey.

Each member of the collective brings a unique element to the group. Tamula Rasta, known for his wisdom and smooth, silky flows, complements the group with his profound lyrical depth. AK Blata, with his explosive lyrics, energizes their tracks, showcasing an intense and powerful style. Fla Pablo adds his distinctive dope swagger, completing the group's dynamic and captivating presence. Together, they represent the diverse and rich tapestry of Ethiopian hip-hop, reflecting the evolving music landscape in the country.

For musicians eager to step in to the world of music, we have set up a dedicated <a href="https:/www.habeshahood.com/upload"> upload page</a>. 

Enjoy the video that is catapulting this talented trio to stardom. Additionally, the video will be available below this article, offering a glimpse into the raw energy and creativity that defines MOB. As they continue their ascent in the Ethiopian music industry, Tamula Rasta, AK Blata, and Fla Pablo are not just artists to watch but are shaping the future of hip-hop in Ethiopia.

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/z438QOsMPUc?si=yCv6OX9pMLPN-gSp&amp;controls=0&amp;start=5showinfo=0" title="YouTube video player" frameborder="0" allowfullscreen></iframe>
